currentDifficulty = 'its still fucked';

function onCreate()
    makeLuaText('10', "Up to 1 Misses", 0, 545, 120);
    setTextAlignment('10', 'left');
    setTextSize('10', 20);
    setTextBorder('10', 1, '000000');
    addLuaText('10');
end

function onCreatePost()
    setProperty('timeBar.y', getProperty('timeBar.y') - 10);
    setProperty('timeTxt.y', getProperty('timeTxt.y') - 10);
end

function onUpdate(elapsed)
    currentDifficulty = getProperty('storyDifficultyText');
    setTextString('10',"Up to 1 Misses");
end