function onUpdate()
getProperty ('songMisses')
if getProperty ('songMisses') == 1 then
setProperty('health', 0);
end
end